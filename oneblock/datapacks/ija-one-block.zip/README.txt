﻿███ ████ ████ █   █ ███ █   █ ████  ██  ███  ████ ████ █████
 █     █ █  █ ██ ██  █  ██  █ █    █  █ █  █ █  █ █      █
 █     █ ████ █ █ █  █  █ █ █ ████ █    ███  ████ ████   █
 █  █  █ █  █ █   █  █  █  ██ █    █  █ █  █ █  █ █      █
███  ██  █  █ █   █ ███ █   █ ████  ██  █  █ █  █ █      █

Website: https://ijaminecraft.com
YouTube: https://www.youtube.com/user/IJAMinecraft



█  █ ████ █   █   █████ ████   █  █ ████ ████
█  █ █  █ █ █ █     █   █  █   █  █ █    █
████ █  █ █ █ █     █   █  █   █  █ ████ ████
█  █ █  █ █ █ █     █   █  █   █  █    █ █
█  █ ████ █████     █   ████   ████ ████ ████

Go here for a guide on how to install this map:
https://ijaminecraft.com/map/oneblock/installation



 ██   ██  ███  █ █ ███  ███  ███ █  █ █████
█  █ █  █ █  █ █ █ █  █  █  █    █  █   █
█    █  █ ███   █  ███   █  █ ██ ████   █
█  █ █  █ █     █  █  █  █  █  █ █  █   █
 ██   ██  █     █  █  █ ███  ██  █  █   █

Read the copyright license here to know how you are allowed to use this work:
https://ijaminecraft.com/en/copyright